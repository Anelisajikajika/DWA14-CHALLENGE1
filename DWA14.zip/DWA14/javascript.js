import { LitElement, html, property } from './lit-element.js';

class NumberInput extends LitElement {
 /** @property({ type: Number }) value = 0;
  *@property({ type: Number }) min = -5;
  *@property({ type: Number }) max = 15;
  *@property({ type: Number }) step = 5;
*/
  updated(changedProperties) {
    if (changedProperties.has('value')) {
      this.updateButtonStates();
    }
  }


   updateButtonStates() {
    const subtractButton = this.shadowRoot?.querySelector('[data-key="subtract"]') 
    const addButton = this.shadowRoot?.querySelector('[data-key="add"]') 

    if (this.value <= this.min) {
      subtractButton.disabled = true;
    } else {
      subtractButton.disabled = false;
    }

    if (this.value >= this.max) {
      addButton.disabled = true;
    } else {
      addButton.disabled = false;
    }
  }

   subtractHandler() {
    if (this.value > this.min) {
      this.value -= this.step;
      this.requestUpdate('value');
    }
  }

  addHandler() {
    if (this.value < this.max) {
      this.value += this.step;
      this.requestUpdate('value');
    }
  }

render() {
    return `

      <input type="number" .value="${this.value}" data-key="number" disabled />
      <button data-key="subtract" @click="${this.subtractHandler}" ?disabled="${this.value <= this.min}">-</button>
      <button data-key="add" @click="${this.addHandler}" ?disabled="${this.value >= this.max}">+</button>
`;
    }

}

customElements.define('number-input', NumberInput);
